# -*- coding: utf-8 -*-
import argparse
import datetime
import os
import subprocess
import sys
import time


class BaseTransfer:
    root_path = os.path.join(os.path.abspath(os.path.dirname(__file__)), "../")

    def exec_command(self, command, command_description='', ssh_ip=None, status_exit=True):
        """
        调用执行 linux 命令
        :param command: 命令
        :param command_description: 命令描述
        :param ssh_ip: 遠程執行命令的電腦 ip
        :param status_exit: 如果命令執行錯誤是否需要退出當前程序
        :return:
        """
        command = command.strip()
        if ssh_ip:
            command = command.replace("'", "'\\''")
            command = f""" ssh {ssh_ip} '{command}' """
        status, output = subprocess.getstatusoutput(command)
        print(output)
        if status != 0 and status_exit:
            sys.exit(1)
        elif self.print_command_result == "true":
            return output

    def hive_query_sql(self, sql, command_description='', status_exit=True):
        sql = sql.replace("\n", "").strip()
        command = f"""
        hive -e '{sql}';
        """.strip()
        return self.exec_command(command, command_description=command_description, status_exit=status_exit)

    def date_to_timestamp(self, date) -> int:
        """
        字符串转毫秒级时间戳
        :rtype: object
        """
        time_array = time.strptime(date, date_format)
        time_stamp = int(time.mktime(time_array)) * 1000
        return time_stamp

    # 把已导入的日期系如记录
    def write_table_data(self, date):
        local_file_path = os.path.join(self.root_path, "data/hive_tables.txt")
        with open(local_file_path, mode="a") as of:
            of.writelines(date)


def run(arg_):
    base_Transfer = BaseTransfer()
    begin_time= "2021-10-11"
    end_time= "2021-10-13"
    begin_time = datetime.datetime.strptime(arg_.begin_time, date_format)
    end_time = datetime.datetime.strptime(arg_.end_time, date_format)
    # 数据导入类型
    days = (end_time - begin_time).days

    local_file_path = os.path.join(base_Transfer.root_path, "data/hive_tables.txt")
    tag_tbales = []
    for line in open(local_file_path):
        tag_tbales.append(str(line))
        print(line)

        # drop 表
        for tag_table_name in tag_tbales:
            for i in range(days):
                current_day = (begin_time + datetime.timedelta(days=i)).strftime(date_format)
                print(current_day)
                base_time = base_Transfer.date_to_timestamp(current_day)

                delete_tag_table_sql = f"""
                                  use etl_sa; ALTER TABLE {tag_table_name} DROP IF EXISTS PARTITION (basetime={base_time});
                               """.strip()
                base_Transfer.hive_query_sql(delete_tag_table_sql,
                                              f"{tag_table_name} delete basetime= {base_time}")


if __name__ == '__main__':
    date_format = "%Y-%m-%d"
    build_parameters = {
        "run": {
            "help": "數據遷移程序",
            "defaults_func": run,
            "arguments": [
                {
                    "args": ['-b', '--begin_time'],
                    "kwargs": {
                        "type": str,
                        "help": "數據起始時間, 如: 2020-01-01(包括當天時間)",
                        "default": "",
                    }
                },
                {
                    "args": ['-e', '--end_time'],
                    "kwargs": {
                        "type": str,
                        "help": "數據結束時間, 如: 2020-01-01(包括當天時間)",
                        "default": "",
                    }
                }
            ],
        },
    }
    parsers = argparse.ArgumentParser()
    subparsers = parsers.add_subparsers(help="tag_transfer")
    for k in build_parameters.keys():
        parsers_k = subparsers.add_parser(k, help=build_parameters[k]["help"])
        for argument in build_parameters[k].get("arguments", list()):
            parsers_k.add_argument(*argument["args"], **argument["kwargs"])
        if build_parameters[k].get("defaults_func"):
            parsers_k.set_defaults(func=build_parameters[k]["defaults_func"])
    args = parsers.parse_args()
    run(args)
